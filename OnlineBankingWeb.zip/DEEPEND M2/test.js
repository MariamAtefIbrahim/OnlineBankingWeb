function greet() {
  console.log('Hello, world!');
}
